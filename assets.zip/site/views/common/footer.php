<footer class="short" id="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-8">
							<h4>PioneerCpL</h4>
															<p> PCPL, headquartered in Jamshedpur, is an Software development company that builds communities based on two beliefs – trust and complete Software solutions... <a href="<?=WEB_SITE_URL;?>about" class="btn-flat btn-xs">View More <i class="icon icon-arrow-right"></i></a></p>
							<hr class="light">
						</div>
						<div class="col-md-3 col-md-offset-1">
							<h5 class="short">Contact Us</h5>
							<span class="phone">(0657) 6571142</span>
							<p class="short">Mobile: (+91) 9934184395</p>
							<p class="short"><i class="icon icon-map-marker"></i> <strong>Address:</strong> Pioneer Computers Pvt Ltd ,<br/>61 A, New Rajendra Nagar ,Sakchi -831001</p>
							<ul class="list icons list-unstyled">
								<li><i class="icon icon-envelope"></i> <a href="mailto:pioneer_pcpl_jsr@redifmail.com"> hr@pioneercpl.com </a></li>
							</ul>
							<div class="social-icons">
								<ul class="social-icons">
									<li class="facebook"><a href="http://www.facebook.com/" target="_blank" data-placement="bottom" rel="tooltip" title="Facebook">Facebook</a></li>
									<li class="twitter"><a href="http://www.twitter.com/" target="_blank" data-placement="bottom" rel="tooltip" title="Twitter">Twitter</a></li>
									<li class="linkedin"><a href="http://www.linkedin.com/" target="_blank" data-placement="bottom" rel="tooltip" title="Linkedin">Linkedin</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="footer-copyright">
					<div class="container">
						<div class="row">
							<div class="col-md-1">
								<a href="index.html" class="logo">
									<img alt="Porto Website Template" class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logo-footer.png">
								</a>
							</div>
							<div class="col-md-11">
								<p>PioneerCpL© Copyright 2014. All Rights Reserved.</p>
							</div>
						</div>
					</div>
				</div>
			</footer>
</div>

		<!-- Libs -->
		<script src="<?=WEB_SITE_DIR;?>vendor/jquery.js"></script>
		<script src="<?=WEB_SITE_DIR;?>js/plugins.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/jquery.easing.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/jquery.appear.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/jquery.cookie.js"></script>
		
		<script src="<?=WEB_SITE_DIR;?>vendor/bootstrap.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/twitterjs/twitter.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.carousel.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/circle-flip-slideshow/js/jquery.flipshow.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/magnific-popup/magnific-popup.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/mediaelement/mediaelement-and-player.js"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/jquery.validate.js"></script>

		<!-- Current Page Scripts -->
		<script src="<?=WEB_SITE_DIR;?>js/views/view.home.js"></script>

		<!-- Theme Initializer -->
		<script src="<?=WEB_SITE_DIR;?>js/theme.js"></script>

		<!-- Custom JS -->
		<script src="<?=WEB_SITE_DIR;?>js/custom.js"></script>

		<!-- Google Analytics: Change UA-XXXXX-X to be your site's ID. Go to http://www.google.com/analytics/ for more information.
		<script type="text/javascript">

			var _gaq = _gaq || [];
			_gaq.push(['_setAccount', 'UA-12345678-1']);
			_gaq.push(['_trackPageview']);

			(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			})();

		</script>
		 -->