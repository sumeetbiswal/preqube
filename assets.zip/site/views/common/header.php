<header>

				<div class="container">

					<h1 class="logo">

						<a href="<?=WEB_SITE_URL;?>home">

							<img alt="Porto" width="150" height="54" data-sticky-width="82" data-sticky-height="40" src="<?=WEB_SITE_DIR;?>img/logo.png">

						</a>

					</h1>

					<div class="search">

						

					</div>

					<nav>

						<ul class="nav nav-pills nav-top">

							<li>

								<span>Get in touch!</span>   

							</li>

							<li>

								<span><i class="icon icon-phone"></i>0657-6571142</span>

							</li>

							<li>
								<span>hr@pioneercpl.com</span>

							</li>

						</ul>

					</nav>

					<button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">

						<i class="icon icon-bars"></i>

					</button>

				</div>

				<div class="navbar-collapse nav-main-collapse collapse">

					<div class="container">

						<div class="social-icons">

							<ul class="social-icons">

								<li class="facebook"><a href="javascript:void(0);" title="Facebook">Facebook</a></li>

								<li class="twitter"><a href="javascript:void(0);" title="Twitter">Twitter</a></li>

								<li class="linkedin"><a href="javascript:void(0);"  title="Linkedin">Linkedin</a></li>

							</ul>

						</div>

						<nav class="nav-main mega-menu">

							<ul class="nav nav-pills nav-main" id="mainMenu">

								<li id="homeli">

									<a href="<?=WEB_SITE_URL;?>">

										Home

									</a>

								</li>

								<li id="aboutli">

									<a class="dropdown-toggle" href="<?=WEB_SITE_URL;?>about">

										About Us

									</a>

									

								</li>

                                <li>

									<a href="<?=WEB_SITE_URL;?>service">Services</a>

								</li>

								<li id="clientli">

									<a href="<?=WEB_SITE_URL;?>clients">Clients</a>

								</li>

                                <li id="productli">

									<a href="<?=WEB_SITE_URL;?>products">Products</a>

								</li>

								<li id="contactli">

									<a href="<?=WEB_SITE_URL;?>contact">Contact</a>

								</li>

							</ul>

						</nav>

					</div>

				</div>

			</header>