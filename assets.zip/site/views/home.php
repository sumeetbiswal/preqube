<!DOCTYPE html>

<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->

<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->

<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->

	<head>



		<!-- Basic -->

		<meta charset="utf-8">

		<title>Pioneer Computers Pvt. Ltd.</title>

		<meta name="keywords" content="HTML5 Template" />

		<meta name="description" content="Porto - Responsive HTML5 Template - 2.9.0">

		<meta name="author" content="okler.net">



		<!-- Mobile Metas -->

		<meta name="viewport" content="width=device-width, initial-scale=1.0">



		<!-- Web Fonts  -->

		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">



		<!-- Libs CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/bootstrap.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/fonts/font-awesome/css/font-awesome.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.carousel.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.theme.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/magnific-popup/magnific-popup.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/mediaelement/mediaelementplayer.css" media="screen">



		<!-- Theme CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-elements.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-animate.css">



		<!-- Current Page Styles -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/rs-plugin/css/settings.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/circle-flip-slideshow/css/component.css" media="screen">



		<!-- Skin CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/skins/blue.css">



		<!-- Custom CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/custom.css">



		<!-- Responsive CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-responsive.css" />



		<!-- Head Libs -->

		<script src="<?=WEB_SITE_DIR;?>vendor/modernizr.js"></script>



		<!--[if IE]>

			<link rel="stylesheet" href="css/ie.css">

		<![endif]-->



		<!--[if lte IE 8]>

			<script src="vendor/respond.js"></script>

		<![endif]-->



	</head>

	<body>



		<div class="body">

			<?php $this->load->view('common/header');?>



			<div role="main" class="main">

				<div id="content" class="content full">



					<div class="slider-container">

						<div class="slider" id="revolutionSlider">

							<ul>

								<li data-transition="fade" data-slotamount="13" data-masterspeed="300" >



									<img src="<?=WEB_SITE_DIR;?>img/custom-header-bg.jpg" data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">



									<div class="tp-caption sft stb visible-lg"

										 data-x="72"

										 data-y="180"

										 data-speed="300"

										 data-start="1000"

										 data-easing="easeOutExpo"><img src="<?=WEB_SITE_DIR;?>img/slides/slide-title-border.png" alt=""></div>



									<div class="tp-caption top-label lfl stl"

										 data-x="122"

										 data-y="180"

										 data-speed="300"

										 data-start="500"

										 data-easing="easeOutExpo">DO YOU WANT TO BE</div>



									<div class="tp-caption sft stb visible-lg"

										 data-x="372"

										 data-y="180"

										 data-speed="300"

										 data-start="1000"

										 data-easing="easeOutExpo"><img src="<?=WEB_SITE_DIR;?>img/slides/slide-title-border.png" alt=""></div>



									<div class="tp-caption main-label sft stb"

										 data-x="30"

										 data-y="210"

										 data-speed="300"

										 data-start="1500"

										 data-easing="easeOutExpo">OUR PARTNER ?</div>



									<div class="tp-caption bottom-label sft stb"

										 data-x="80"

										 data-y="280"

										 data-speed="500"

										 data-start="2000"

										 data-easing="easeOutExpo">Check out our products and services.</div>



									<div class="tp-caption customin customout"

										data-x="right" data-hoffset="0"

										data-y="bottom" data-voffset="0"

										data-customin="x:50;y:150;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.5;scaleY:0.5;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"

										data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"

										data-speed="800"

										data-start="700"

										data-easing="Power4.easeOut"

										data-endspeed="500"

										data-endeasing="Power4.easeIn"

										style="z-index: 3"><img src="<?=WEB_SITE_DIR;?>img/slides/mobile-device.png" alt="">

									</div>

								</li>

								<li data-transition="fade" data-slotamount="13" data-masterspeed="300" >



									<img src="<?=WEB_SITE_DIR;?>img/custom-header-bg.jpg" data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">



									<div class="tp-caption customin customout"

										data-x="center" data-hoffset="0"

										data-y="center" data-voffset="0"

										data-customin="x:50;y:150;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.5;scaleY:0.5;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"

										data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"

										data-speed="800"

										data-start="700"

										data-easing="Power4.easeOut"

										data-endspeed="500"

										data-endeasing="Power4.easeIn"

										style="z-index: 3"><img src="<?=WEB_SITE_DIR;?>img/slides/slide-concept-draft.png" alt="">

									</div>



									<div class="tp-caption customin customout"

										data-x="center" data-hoffset="0"

										data-y="center" data-voffset="-6"

										data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:5;scaleY:5;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"

										data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"

										data-speed="600"

										data-start="100"

										data-easing="Power4.easeOut"

										data-endspeed="500"

										data-endeasing="Power4.easeOut"

										data-autoplay="false"

										data-autoplayonlyfirsttime="false"

										style="z-index: 8">

									</div>



								</li>

							</ul>

						</div>

					</div>



					<div class="home-intro">

						<div class="container">



							<div class="row">

								<div class="col-md-8">

									<p>

										The fastest way to grow your business with the leader in <em>Technology.</em>

										<span>Check out our options and features included.</span>

									</p>

								</div>

								<div class="col-md-4">

									<div class="get-started">

										<a href="#" class="btn btn-lg btn-primary">Get Started Now!</a>

										<div class="learn-more">or <a href="index.html">learn more.</a></div>

									</div>

								</div>

							</div>



						</div>

					</div>



					<div class="home-concept">

						<div class="container">



							<div class="row center">

								<span class="sun"></span>

								<span class="cloud"></span>

								<div class="col-md-2 col-md-offset-1">

									<div class="process-image" data-appear-animation="bounceIn">

										<img src="<?=WEB_SITE_DIR;?>img/home-concept-item-3.jpg" alt="" style="height:145px; width:145px;"/>

										<strong>Strategy</strong>

									</div>

								</div>

								<div class="col-md-2">

									<div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="200">

										<img src="<?=WEB_SITE_DIR;?>img/home-concept-item-2.jpg" alt="" style="height:145px; width:145px;"/>

										<strong>Planning</strong>

									</div>

								</div>

								<div class="col-md-2">

									<div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="400">

										<img src="<?=WEB_SITE_DIR;?>img/home-concept-item-1.jpg" alt="" style="height:145px; width:145px;" />

										<strong>Build</strong>

									</div>

								</div>

								<div class="col-md-4 col-md-offset-1">

									<div class="project-image">

										<div id="fcSlideshow" class="fc-slideshow">

											<ul class="fc-slides">

												<li><a href="portfolio-single-project.html"><img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/projects/contact-us.jpg" /></a></li>

												<li><a href="portfolio-single-project.html"><img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/projects/Client.jpg" /></a></li>

												<li><a href="portfolio-single-project.html"><img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/projects/TRAINING.png" /></a></li>

											</ul>

										</div>

										<strong class="our-work">Our Work</strong>

									</div>

								</div>

							</div>



						</div>

					</div>



					<div class="container">

						<div class="row">

							<hr class="tall" />

						</div>

						<div class="row">

							<div class="col-md-12">

								<div class="row">

									<div class="col-md-4">

										<div class="feature-box secundary">

											<div class="feature-box-icon">

												<i class="icon icon-group"></i>

											</div>

											<div class="feature-box-info">

												<h4 class="shorter">ERP -SAP</h4>

												<p class="tall" style="text-align:justify;">SAP Business ByDesign provides all important functions required in everyday business life, offering comprehensive support features, which help you to operate the software.</p>

											</div>

										</div>

										<div class="feature-box secundary">

											<div class="feature-box-icon">

												<i class="icon icon-file"></i>

											</div>

											<div class="feature-box-info">

												<h4 class="shorter">C++</h4>

												<p class="tall" style="text-align:justify;">The C++ comprises of a variety of optional packages that implementers and developers can choose to construct a complete C++ runtime environment that closely fit the requirements of  target market.</p>

											</div>

										</div>

									</div>

									<div class="col-md-4">

										<div class="feature-box secundary">

											<div class="feature-box-icon">

												<i class="icon icon-film"></i>

											</div>

											<div class="feature-box-info">

												<h4 class="shorter">Dot Net</h4>

												<p class="tall" style="text-align:justify;">The Dot Net Platform provides a robust, flexible environment for software applications running on consumer system to get its requirements.</p>

											</div>

										</div>

										<div class="feature-box secundary">

											<div class="feature-box-icon">

												<i class="icon icon-check"></i>

											</div>

											<div class="feature-box-info">

												<h4 class="shorter">Messaging Architecture</h4>

												<p class="tall" style="text-align:justify;">This first of a two-part series discusses how messaging patterns exist at different levels of abstraction in SOA. Rather than explicitly declaring how systems will interact through low-level protocols and object-oriented architectures.</p>

											</div>

										</div>

									</div>

									<div class="col-md-4">

										<div class="feature-box secundary">

											<div class="feature-box-icon">

												<i class="icon icon-bars"></i>

											</div>

											<div class="feature-box-info">

												<h4 class="shorter">Oracle d2k</h4>

												<p class="tall" style="text-align:justify;">Report Builder meets this challenge by making it easy to design, publish, and distribute professional, production-quality reports in a variety of formats to meet any business need.</p>

											</div>

										</div>

										<div class="feature-box secundary">

											<div class="feature-box-icon">

												<i class="icon icon-desktop"></i>

											</div>

											<div class="feature-box-info">

												<h4 class="shorter">Data Entry</h4>

												<p class="tall" style="text-align:justify;">Utilize a variety of online tools, applications and platforms to input data into forms used at various social media and directory websites.</p>

											</div>

										</div>

									</div>

								</div>

							</div>

						</div>



					</div>



					<section class="featured highlight footer">

						<div class="container">

							<div class="row center counters">

								<div class="col-md-3">

									<strong data-to="800">0</strong>

									<label>Happy Clients</label>

								</div>

								<div class="col-md-3">

									<strong data-to="15">0</strong>

									<label>Years in Business</label>

								</div>

								<div class="col-md-3">

									<strong data-to="10">0</strong>

									<label>Cups of Coffee</label>

								</div>

								<div class="col-md-3">

									<strong data-to="1000">0</strong>

									<label>Gigh Score</label>

								</div>

							</div>

						</div>

					</section>



					<section class="video" style="background-image: url(img/slides/men-in-black.jpg);">

						<div class="container">

							<div class="row center">

								<div class="col-md-12">



									<div class="row">

										<div class="owl-carousel" data-plugin-options='{"items": 1}'>

											<div>

												<blockquote>

													<p><i class="icon icon-quote-left"></i> Hello, I want to thank you for giving affordable services and for the excellent and quick support and help that you have been providing to me as I begin to work with it.</p>

													<span>- Joe Doe</span>

												</blockquote>

											</div>

											<div>

												<blockquote>

													<p><i class="icon icon-quote-left"></i> Just want to say Thanks for Providing great tech service for each session and allows me to become more knowledgeable as a architecture.</p>

													<span>- Edward Chelton</span>

												</blockquote>

											</div>

											<div>

												<blockquote>

													<p><i class="icon icon-quote-left"></i> Just came here to say a big thank you to the author of the techsolution. It works amazingly well, the documentation is top-notch, and the soluions become best.</p>

													<span>- Bruce Ericson</span>

												</blockquote>

											</div>

										</div>

									</div>



								</div>

							</div>

						</div>

						<video autoplay loop poster="img/slides/men-in-black.jpg" width="1920" height="495" data-plugin-options='{"features": []}'>

							<source src="<?=WEB_SITE_DIR;?>video/men-in-black.mp4"  type='video/mp4;  codecs="avc1.42E01E, mp4a.40.2"'>

							<source src="<?=WEB_SITE_DIR;?>video/men-in-black.ogv"  type='video/ogg;  codecs="theora, vorbis"'>

						</video>

					</section>



					<div class="container">

						<div class="row center">

							<div class="col-md-12">

								<h2 class="short word-rotator-title">

									With our Service We contribute to your success

									<strong>

										<!--<span class="word-rotate">

											<span class="word-rotate-items">

												<span>excited</span>

												<span>happy</span>

											</span>

										</span>-->

									</strong>

									

								</h2>
<!--
								<h4 class="lead tall">5,500 customers in 100 countries use Porto Template. Meet our customers.</h4>
-->
							</div>

						</div>

					</div>



					<div class="container">

						<div class="row center">

							<div class="owl-carousel" data-plugin-options='{"items": 6, "singleItem": false, "autoPlay": true}'>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/tatatrf.png" alt="">

								</div>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/tatamo.png" alt="">

								</div>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/tatapo.png" alt="">

								</div>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/tatatin1.png" alt="">

								</div>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/tatast.png" alt="">

								</div>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/tatablue.png" alt="">

								</div>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/images.png" alt="">

								</div>

								<div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/new_ch_IBM-Logo.png" alt="">

								</div>
                                <div>

									<img class="img-responsive" src="<?=WEB_SITE_DIR;?>img/logos/data2-pq-id-imfcp-3221186-dm-1613007053104-90x90.png" alt="">

								</div>
                               
							</div>

						</div>

					</div>



					<div class="map-section">

						

					</div>



				</div>

			</div>



  <?php $this->load->view('common/footer');?>

<script type="text/javascript">         
              $("li#homeli").addClass('active');
</script>

	</body>

</html>

