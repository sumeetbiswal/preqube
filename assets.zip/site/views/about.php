<!DOCTYPE html>

<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->

<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->

<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->

	<head>



		<!-- Basic -->

		<meta charset="utf-8">

		<title>Pioneer Computers Pvt. Ltd.</title>

		<meta name="keywords" content="HTML5 Template" />

		<meta name="description" content="Porto - Responsive HTML5 Template - 2.9.0">

		<meta name="author" content="okler.net">



		<!-- Mobile Metas -->

		<meta name="viewport" content="width=device-width, initial-scale=1.0">



		<!-- Web Fonts  -->

		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">



		<!-- Libs CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/bootstrap.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/fonts/font-awesome/css/font-awesome.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.carousel.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.theme.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/magnific-popup/magnific-popup.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/mediaelement/mediaelementplayer.css" media="screen">



		<!-- Theme CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-elements.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-animate.css">



		<!-- Current Page Styles -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/rs-plugin/css/settings.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/circle-flip-slideshow/css/component.css" media="screen">



		<!-- Skin CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/skins/blue.css">



		<!-- Custom CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/custom.css">



		<!-- Responsive CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-responsive.css" />



		<!-- Head Libs -->

		<script src="<?=WEB_SITE_DIR;?>vendor/modernizr.js"></script>



		<!--[if IE]>

			<link rel="stylesheet" href="css/ie.css">

		<![endif]-->



		<!--[if lte IE 8]>

			<script src="vendor/respond.js"></script>

		<![endif]-->



	</head>

	<body>



		<div class="body">

			<?php $this->load->view('common/header');?>



			<div role="main" class="main">

				<section class="page-top">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<ul class="breadcrumb">
									<li><a href="<?=WEB_SITE_URL;?>">Home</a></li>
									<li class="active">About Us</li>
								</ul>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<h2>About Us</h2>
							</div>
						</div>
					</div>
				</section>

				<div class="container">

					<h2 class="word-rotator-title">
						<h3><strong>Who</strong> We Are</h3><strong>
							
						</strong>
					</h2>

					<div class="row">
						<div class="col-md-10">
							<p class="row" style="text-align:justify;">
								Since 1999, we've been totally dedicated to our candidates and clients. Today, Pioneer Compters is one of the most trusted names in Permanent and Temporary Staffing across India. We work with the greatest employers and every day we handle numerous jobs, from entry level to senior management positions. Pioneer Compters we pride ourselves on having an eye for what our clients and candidates need. We offer an honest and open service, coupled with the experience that over ten years of recruitment brings. In the recruitment world reputation is everything. So we're proud to say that over 35% of our candidates arerecommendations from job seekers we've assisted in the past.
							</p>
						</div>
						
					</div>

					<hr class="tall" style="margin:20px;">

					<div class="row">
						<div class="col-md-8">
							<h3><strong>Why</strong> We Are ?</h3><strong>
							<p style="text-align:justify;">
                            <ul class="list icons list-unstyled">
                            	<li><i class="icon icon-check"></i> Our ability to screen, tests, and interview in depth all candidates before hiring- we know our &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;consultants.</li>
<li><i class="icon icon-check"></i> Our specialization in different Industrial Segments.</li>
<li><i class="icon icon-check"></i>Efficient matching of Candidates as per requirements.</li>
<li><i class="icon icon-check"></i>Responsive client relations are a priority to maximize our Consultant's effectiveness.</li>
<li><i class="icon icon-check"></i>Unmatched professionalism and commitment to client satisfaction.</li>
							</ul>
							 </p>
							
						</div>
						<div class="col-md-4">
							<div class="featured-box featured-box-secundary">
								<div class="box-content">
									<h4>Behind the scenes</h4>
									<ul class="thumbnail-gallery flickr-feed" data-plugin-options='{"qstrings": { "id": "93691989@N03" }}'></ul>
                                    <img src="<?=WEB_SITE_DIR;?>img/aboutus.jpg" alt="0" width="200"/>
								</div>
							</div>
						</div>
					</div>

					<hr class="tall" style="margin:20px;">

					<div class="row">
						<div class="col-md-12">
							<h3 class="push-top">Our <strong>Goals</strong></h3>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">

							<ul class="history">
								<li data-appear-animation="fadeInUp">
									<div class="thumb">
										<img src="<?=WEB_SITE_DIR;?>img/objective.jpg" alt="Objective" />
									</div>
									<div class="featured-box">
										<div class="box-content">
											
											<p style="text-align:justify;">Our tactical ability and professionalism, delivers superior candidates who will have an immediate impact on your company today and will become invaluable to your future. Kapasa Jobs access to immense global human resources with modern and latest communication technology and system which assists us in explore the best skill that meet exact need of our organization.<br>
	 
  	
<i class="icon icon-check"></i> Our Philosophy is to focus on achieving client results. <br>
<i class="icon icon-check"></i> Dedication to client collaboration and teamwork.<br>
<i class="icon icon-check"></i> Strong Spirit of Collegiality.<br>
<i class="icon icon-check"></i> Extraordinary Commitment to People.<br>
<i class="icon icon-check"></i> Belief in Professional excellence. </p>
										</div>
									</div>
								</li>
								<li data-appear-animation="fadeInUp">
									<div class="thumb">
										<img src="<?=WEB_SITE_DIR;?>img/methodology2.jpg" alt="" />
									</div>
									<div class="featured-box">
										<div class="box-content">
											
											<p style="text-align:justify;"><i class="icon icon-check"></i> Obtaining the requirements and specifications of the assignments from the company. <br/>
<i class="icon icon-check"></i> Screening the Candidates before forwarding to the respective clients. <br/>
<i class="icon icon-check"></i> <span style="text-align:start;">Arranging interviews of further short-listed candidates by the company. Searching right candidates for the right employers.</span> <br/>
<i class="icon icon-check"></i> Presenting CVs of short-listed and benchmarked candidates or sending them direct to the company. <br/>
<i class="icon icon-check"></i> Obtaining feedback on candidate's performance in the respective interview.</p>
										</div>
									</div>
								</li>
								
								
							</ul>

						</div>
					</div>

				</div>

			</div>



  <?php $this->load->view('common/footer');?>

<script type="text/javascript">         
              $("li#aboutli").addClass('active');
</script>

	</body>

</html>

