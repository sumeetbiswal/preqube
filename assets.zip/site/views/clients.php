<!DOCTYPE html>

<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->

<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->

<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->

	<head>



		<!-- Basic -->

		<meta charset="utf-8">

		<title>Pioneer Computers Pvt. Ltd.</title>

		<meta name="keywords" content="HTML5 Template" />

		<meta name="description" content="Porto - Responsive HTML5 Template - 2.9.0">

		<meta name="author" content="okler.net">



		<!-- Mobile Metas -->

		<meta name="viewport" content="width=device-width, initial-scale=1.0">



		<!-- Web Fonts  -->

		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">



		<!-- Libs CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/bootstrap.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/fonts/font-awesome/css/font-awesome.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.carousel.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.theme.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/magnific-popup/magnific-popup.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/mediaelement/mediaelementplayer.css" media="screen">



		<!-- Theme CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-elements.css">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-animate.css">



		<!-- Current Page Styles -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/rs-plugin/css/settings.css" media="screen">

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/circle-flip-slideshow/css/component.css" media="screen">



		<!-- Skin CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/skins/blue.css">



		<!-- Custom CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/custom.css">



		<!-- Responsive CSS -->

		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-responsive.css" />



		<!-- Head Libs -->

		<script src="<?=WEB_SITE_DIR;?>vendor/modernizr.js"></script>



		<!--[if IE]>

			<link rel="stylesheet" href="css/ie.css">

		<![endif]-->



		<!--[if lte IE 8]>

			<script src="vendor/respond.js"></script>

		<![endif]-->



	</head>

	<body>



		<div class="body">

			<?php $this->load->view('common/header');?>



			<div role="main" class="main">

				<section class="page-top">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<ul class="breadcrumb">
									<li><a href="<?=WEB_SITE_URL;?>">Home</a></li>
									<li class="active">clients</li>
								</ul>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<h2>Clients</h2>
							</div>
						</div>
					</div>
				</section>

				<div class="container">

					<h2 class="word-rotator-title">
						<h3><strong>Clients</strong></h3><strong>
							
						</strong>
					</h2>

					<div class="row">
						<div class="col-md-10">
							<p class="row" style="text-align:justify;">We provide assessment and development solutions to clients from all sectors of IT, industry and government. As consultants that specialise in the design and development of solutions that are built exactly according to each client's requirements, we do not promote a 'one-size-fits-all' approach.
	<br/>

Whether the software developed is for internal use or it is sold as a product, the capability to deliver the best quality within a given time-frame, is the deciding factor to any organization's success. Pioner Computer Pvt Ltd is envisioned at setting up global standards by integrating all quality aspects of services by providing "ONLY BEST SOLUTIONS".<br/>

					To ensure the success of your international projects, you need a partner with global, regional and local consulting expertise, and service capabilities that are available worldwide. As the leading global SAP full-service provider, itelligence is today's strategic IT partner to numerous national and multinational companies, for both mid-sized and large business clients. 
					</p>
						</div>
						
					</div>

					<hr class="tall">

					<div class="row">
						<div class="col-md-8">
							<h3> <strong>OMS</strong></h3><strong>
							<p style="text-align:justify;">
                            Open Management System(OMS) is a complete online solution to work on complete team management factors like enhancing productivity, collaboration, communication and management.
Main features of OMS includes project management, time management, contact management, document management. Documents and presentations independent of file formats can be organized online. 
						</p>
							
						</div>
                        <div class="col-md-8">
							<h3> <strong>OTMS</strong></h3><strong>
							<p style="text-align:justify;">
                            One Touch Management System is a desktop software application that fulfills the need of contact center agents. Irrespective of the place where they are working, contact center agents can enhance their productivity through one touch functions of OTMS like transfer, conference, manage communications and agent tasks, etc.
						</p>
							
						</div>
                        <div class="col-md-8">
							<h3> <strong>EGM</strong></h3><strong>
							<p style="text-align:justify;">
E-Group Manage is a software that assists business enterprises by managing to-do lists, appointments, contacts, projects, etc. It can be used by different supported groupware clients or via web interface.						</p>
							
						</div>
						<div class="col-md-4">
							<div class="featured-box featured-box-secundary">
								<div class="box-content">
									<h4>Behind the scenes</h4>
									<ul class="thumbnail-gallery flickr-feed" data-plugin-options='{"qstrings": { "id": "93691989@N03" }}'></ul>
                                    <img src="<?=WEB_SITE_DIR;?>img/aboutus.jpg" alt="0" width="200"/>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>



  <?php $this->load->view('common/footer');?>

<script type="text/javascript">         
              $("li#clientli").addClass('active');
</script>

	</body>

</html>

