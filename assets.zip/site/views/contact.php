<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
	<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<title>Pioneer Computers Pvt. Ltd.</title>
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" content="PioneerCpL">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Libs CSS -->
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/bootstrap.css">
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/fonts/font-awesome/css/font-awesome.css">
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/owl-carousel/owl.theme.css" media="screen">
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>vendor/magnific-popup/magnific-popup.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme.css">
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-elements.css">
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-animate.css">

		<!-- Skin CSS -->
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/skins/blue.css">

		<!-- Custom CSS -->
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/custom.css">

		<!-- Responsive CSS -->
		<link rel="stylesheet" href="<?=WEB_SITE_DIR;?>css/theme-responsive.css" />

		<!-- Head Libs -->
		<script src="<?=WEB_SITE_DIR;?>vendor/modernizr.js"></script>

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->

		<!--[if lte IE 8]>
			<script src="vendor/respond.js"></script>
		<![endif]-->

	</head>
	<body>

		<div class="body">
			<?php $this->load->view('common/header');?>
            
            <section class="page-top">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<ul class="breadcrumb">
									<li><a href="<?=WEB_SITE_URL;?>home">Home</a></li>
									<li class="active">Contact Us</li>
								</ul>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<h2>Contact Us</h2>
							</div>
						</div>
					</div>
				</section>

			<div role="main" class="main">

				<!-- Google Maps -->
				<div id="googlemaps" class="google-map hidden-xs"></div>

				<div class="container">

					<div class="row">
						<div class="col-md-6">

							<div class="alert alert-success hidden" id="contactSuccess">
								<strong>Success!</strong> Your message has been sent to us.
							</div>

							<div class="alert alert-danger hidden" id="contactError">
								<strong>Error!</strong> There was an error sending your message.
							</div>

							<h2 class="short"><strong>Contact</strong> Us</h2>
							<form action="<?=WEB_SITE_URL;?>contact" id="contactForm" name="contactForm" method="post" enctype="multipart/form-data">
								<div class="row">
									<div class="form-group">
										<div class="col-md-6">
											<label>Your name *</label>
											<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="name" id="name" required>
										</div>
										<div class="col-md-6">
											<label>Your email address *</label>
											<input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="Please enter a valid email address." maxlength="100" class="form-control" name="email" id="email" required>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<div class="col-md-12">
											<label>Subject</label>
											<input type="text" value="" data-msg-required="Please enter the subject." maxlength="100" class="form-control" name="subject" id="subject" required>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<div class="col-md-12">
											<label>Message *</label>
											<textarea maxlength="5000" data-msg-required="Please enter your message." rows="10" class="form-control" name="message" id="message" required></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<input type="submit" value="Send Message" class="btn btn-primary btn-lg" data-loading-text="Loading...">
									</div>
								</div>
							</form>
						</div>
						<div class="col-md-6">

							<h4 class="push-top">Get in <strong>touch</strong></h4>
							<p>We are here to answer any questions you may have about our experiences. Reach out to us and we'll respond as soon as we can.</p>
                            <p>Even if there is something you have always wanted to experience and can't find it on here, let us know and we promise we'll do our best to find it for you and send you there.</p>

							<hr />
                                                        
                            </div>
   

			
                          <div class="col-md-6">
							<h3>Office Address</h3>
							<div class="toogle">
                            <?php
						
							if(!empty($office))
							{
								foreach($office as $value)
								{ ?>
								<section class="toggle">
									<label><?=$value->address_lable;?></label>
									<div class="toggle-content">
                                            <ul class="list-unstyled">
                                            	<li><i class="icon icon-user"></i> <strong>Contact Person: </strong><?=$value->contact_person;?></li>
                                                <li><i class="icon icon-map-marker"></i> <strong>Address: </strong><?=$value->address;?></li>
                                                <li><i class="icon icon-phone-square "></i> <strong>Phone: </strong><?=$value->phone;?></li>
                                                <li><i class="icon icon-phone"></i> <strong>Mobile: </strong><?=$value->mobile;?></li>
                                                <?php
													$ids = $value->email;
													$ids = explode(',',$ids);
													$i = 0;
													$len = count($ids);
												?>
                                                <li><i class="icon icon-envelope"></i> <strong>Email: </strong>
                                                <?php
                                                	foreach($ids as $kye=>$value)
														{
															if($i != $len - 1)
															{
                                                ?>
                                                 <a href="mailto:<?=$value?>"> <?=$value?></a>
                                                 <?php
												 			echo ", ";
															}
												 			else 
															{
												 ?>
                                                 <a href="mailto:<?=$value?>"> <?=$value?></a>
                                                 <?php
												 			echo ".";
															}
												 $i++; } ?>
                                                </li>
                                            </ul>
									</div>
								</section>
                        <?php	}	
							}
							else
							{  ?>
								<section class="toggle active">
									<label>We are setting up....</label>
									<div class="toggle-content">
                                            <ul class="list-unstyled">
                                            	<li><strong>Our office address will be available soon...</strong></li>
                                            </ul>
									</div>
								</section>
                          <?php } ?>
								
							</div>
						</div>
                      </div>
                    </div>


			<section class="call-to-action featured footer">
				<div class="container">
					<div class="row">
						<div class="center">
							<h3>With our Services We contribute to your success<span class="arrow hlb" data-appear-animation="rotateInUpLeft" style="top: -22px;"></span></h3>
						</div>
					</div>
				</div>
			</section>

			<?php $this->load->view('common/footer');?>
		

		<!-- Libs -->

		<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<script src="<?=WEB_SITE_DIR;?>vendor/jquery.gmap.js"></script>

		<script>

			var mapMarkers = [{
				address: "Jamshedpur, Jharkhand",
				html: "<strong>PCPL</strong><br>INDIA",
				icon: {
					image: "<?=WEB_SITE_DIR;?>img/pin.png",
					iconsize: [26, 46],
					iconanchor: [12, 46]
				},
				popup: true
			}];

			// Map Initial Location
			var initLatitude = 22.808308;
			var initLongitude = 86.208469;

			// Map Extended Settings
			var mapSettings = {
				controls: {
					panControl: true,
					zoomControl: true,
					mapTypeControl: true,
					scaleControl: true,
					streetViewControl: true,
					overviewMapControl: true
				},
				scrollwheel: false,
				markers: mapMarkers,
				latitude: initLatitude,
				longitude: initLongitude,
				zoom: 14
			};

			var map = $("#googlemaps").gMap(mapSettings);

			// Map Center At
			var mapCenterAt = function(options, e) {
				e.preventDefault();
				$("#googlemaps").gMap("centerAt", options);
			}

		</script>
		<script type="text/javascript">         
              $("li#contactli").addClass('active');
		</script>
	</body>
</html>
