<?php 

class Contact_model extends CI_Model {
	
	public function __construct()
    {
      parent::__construct();
	
    }
	
	public function getOffices()
	{
		$this->db->select('*');	
		$this->db->from('office_address');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return  false;
	}
	
	public function insertContact($data)
	{
		$this->db->insert('contact_enquiry',$data);	
		
		if($this->db->insert_id())	
			return true;
		else
			return false;
	}
	
}

