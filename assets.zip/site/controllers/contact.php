<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Contact extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('contact_model','contact');
		if( ! ini_get('date.timezone') )
		{
			date_default_timezone_set('GMT');
		}
	}

	public function index()
	{
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			extract($_POST);
		
			$data = array(
			
							'name'		=>		$name,
							'email'		=>		$email,
							'subject'	=>		$subject,
							'message'	=>		$message,
							'requeston'	=>		date('d-m-Y H:i:m:s')
						
						);
						
			$this->contact->insertContact($data);
			
			 $date = date('d-m-Y');
				   $to  = 'shashank@preludedegital.com';
				   
				   $subject = "Conatct Enquiry For PCPL";
				   
				   $message = '
					<html>
				   <head>
				   <title>:: Enquiry Details ::</title>
				   </head>
				   
				   <body>
				   <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
					 <tr>
					<td align="left" valign="middle" bgcolor="#E6E6E6" style="padding:10px 10px; font:bold 12px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #bcbcbc">Enquiry Details :<br />
					<div style="font:bold 12px Arial, Helvetica, sans-serif; color:#3E3E3E; text-decoration:none; text-align:left">Date : '.$date.'</div>
					</td>
					 </tr>
				   </table>
				   <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
					 <tr>
					<td align="left" valign="middle" height="4"></td>
					 </tr>
				   </table>
				   <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center" style="background-color:#f3f3f3; border:1px solid #bcbcbc">
					 <tr>
					<td align="left" valign="top" style="padding:20px"><table width="100%" border="0" cellspacing="5" cellpadding="0">
					 <tr>
					 <td width="15%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">Name</td>
					  <td width="85%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">'.$name.'</td>
					</tr>
					 <tr>
					 <td width="15%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">Email</td>
					  <td width="85%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">'.addslashes($email).'</td>
					</tr>
					<tr>
					 <td width="15%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">Subject</td>
					  <td width="85%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">'.$subject.'</td>
					</tr>
					<tr>
					 <td width="15%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">Message</td>
					  <td width="85%" bgcolor="#FBFBFB" style="padding:8px 6px 8px 12px; font:bold 11px Arial, Helvetica, sans-serif; color:#2E7030; border:1px solid #dfdfdf">'.$message.'</td>
					</tr>
					</table></td>
					 </tr>
				   </table>
				   </body>
				   </html>
				   ';
				   
				   
				   $headers  = 'MIME-Version: 1.0' . "\r\n";
				   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				   
				   $headers .= "From: Contact Page" . "\r\n";
				   //$headers .= "Bcc: shashank@preludedigital.com" . "\r\n";
				   
				   mail($to, $subject, $message, $headers);
		}
		
		$data['office'] = $this->contact->getOffices();
				   
		$this->load->view('contact',$data);
	}

}

