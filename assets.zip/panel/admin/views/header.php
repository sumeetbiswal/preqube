<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Sentir, Responsive admin and dashboard UI kits template">
		<meta name="keywords" content="admin,bootstrap,template,responsive admin,dashboard template,web apps template">
		<meta name="author" content="Ari Rusmanto, Isoh Design Studio, Warung Themes">
		<title><?php echo $title; ?></title>
 

		<!-- BOOTSTRAP CSS (REQUIRED ALL PAGE)-->
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/css/bootstrap.min.css" rel="stylesheet">
		
		<!-- PLUGINS CSS -->
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/weather-icon/css/weather-icons.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/prettify/prettify.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/magnific-popup/magnific-popup.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/owl-carousel/owl.carousel.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/owl-carousel/owl.theme.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/owl-carousel/owl.transitions.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/chosen/chosen.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/icheck/skins/all.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/datepicker/datepicker.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/validator/bootstrapValidator.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/summernote/summernote.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/markdown/bootstrap-markdown.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/datatable/css/bootstrap.datatable.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/morris-chart/morris.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/c3-chart/c3.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/slider/slider.min.css" rel="stylesheet">
		
		<!-- MAIN CSS (REQUIRED ALL PAGE)-->
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/css/style.css" rel="stylesheet">
		<link href="<?php echo WEB_ADMIN_DIR; ?>assets/css/style-responsive.css" rel="stylesheet">
 
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
 
	<body class="tooltips">
		
		<!-- BEGIN PANEL DEMO -->
		<div class="box-demo">
			<div class="inner-panel">
				
				<p class="text-muted small text-center">COLOR SCHEMES</p>
				<div class="row text-center">
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Default" id="color-reset">
							<div class="half-tiles bg-dark"></div>
							<div class="half-tiles bg-dark"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Light" id="change-color-light">
							<div class="half-tiles bg-white"></div>
							<div class="half-tiles bg-white"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Primary dark" id="change-primary-dark">
							<div class="half-tiles bg-primary"></div>
							<div class="half-tiles bg-dark"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Info dark" id="change-info-dark">
							<div class="half-tiles bg-info"></div>
							<div class="half-tiles bg-dark"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Success dark" id="change-success-dark">
							<div class="half-tiles bg-success"></div>
							<div class="half-tiles bg-dark"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Danger dark" id="change-danger-dark">
							<div class="half-tiles bg-danger"></div>
							<div class="half-tiles bg-dark"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Warning dark" id="change-warning-dark">
							<div class="half-tiles bg-warning"></div>
							<div class="half-tiles bg-dark"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Primary light" id="change-primary-light">
							<div class="half-tiles bg-primary"></div>
							<div class="half-tiles bg-white"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Info light" id="change-info-light">
							<div class="half-tiles bg-info"></div>
							<div class="half-tiles bg-white"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Success light" id="change-success-light">
							<div class="half-tiles bg-success"></div>
							<div class="half-tiles bg-white"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Danger light" id="change-danger-light">
							<div class="half-tiles bg-danger"></div>
							<div class="half-tiles bg-white"></div>
						</div>
					</div>
					<div class="col-xs-3">
						<div class="xs-tiles" data-toggle="tooltip" title="Warning light" id="change-warning-light">
							<div class="half-tiles bg-warning"></div>
							<div class="half-tiles bg-white"></div>
						</div>
					</div>
				</div>
				<button class="btn btn-block btn-primary btn-sm" id="btn-reset">Reset to default</button>
			</div>
		</div>
		<!-- END PANEL DEMO -->
		
		
		<!--
		===========================================================
		BEGIN PAGE
		===========================================================
		-->
		<div class="wrapper">
			<!-- BEGIN TOP NAV -->
			<div class="top-navbar">
				<div class="top-navbar-inner">
					
					<!-- Begin Logo brand -->
					<div class="logo-brand">
						<a href="<?php echo WEB_ADMIN_DIR; ?>manage"><img src="<?php echo WEB_ADMIN_DIR; ?>assets/img/logo.png" height="60" alt="Jupiter logo"></a>
					</div><!-- /.logo-brand -->
					<!-- End Logo brand -->
					
					<div class="top-nav-content">
						
						<!-- Begin button sidebar left toggle -->
						<div class="btn-collapse-sidebar-left">
							<i class="fa fa-long-arrow-right icon-dinamic"></i>
						</div><!-- /.btn-collapse-sidebar-left -->
						<!-- End button sidebar left toggle -->
						
						<!-- Begin button sidebar right toggle -->
					
						<!-- End button sidebar right toggle -->
						
						<!-- Begin button nav toggle -->
						<div class="btn-collapse-nav" data-toggle="collapse" data-target="#main-fixed-nav">
							<i class="fa fa-plus icon-plus"></i>
						</div><!-- /.btn-collapse-sidebar-right -->
						<!-- End button nav toggle -->
						
						
						<!-- Begin user session nav -->
						<ul class="nav-user navbar-right">
							<li class="dropdown">
							  <a href="#fakelink" class="dropdown-toggle" data-toggle="dropdown">
								<img src="<?php echo WEB_ADMIN_DIR; ?>assets/img/logo.PNG" class="avatar img-circle" alt="Avatar">
								Hi, <strong><?php echo $this->session->userdata('name'); ?></strong>
							  </a>
							  <ul class="dropdown-menu square primary margin-list-rounded with-triangle">
        
                            	<li><a href="<?php echo WEB_ADMIN_URL; ?>manage/password">Change password</a></li>
                            	<li><a href="<?php echo WEB_ADMIN_URL; ?>login/logout">Log out</a></li>
                             </ul>
							</li>
						</ul>
						<!-- End user session nav -->
						
						<!-- Begin Collapse menu nav -->
						<div class="collapse navbar-collapse" id="main-fixed-nav">
							
							<ul class="nav navbar-nav navbar-left">
								<!-- Begin nav notification -->
								
								<!-- End nav notification -->
								<!-- Begin nav task -->
								
								<!-- End nav task -->
								<!-- Begin nav message -->
								
								<!-- End nav message -->
								<!-- Begin nav friend requuest -->
								
								<!-- End nav friend requuest -->
							</ul>
						</div><!-- /.navbar-collapse -->
						<!-- End Collapse menu nav -->
					</div><!-- /.top-nav-content -->
				</div><!-- /.top-navbar-inner -->
			</div><!-- /.top-navbar -->
			<!-- END TOP NAV -->
			
			