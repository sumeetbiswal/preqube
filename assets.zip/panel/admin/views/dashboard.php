<?php $this->load->view('header');
	$this->load->view('side'); ?>

                    <div class="page-content">
				<div class="container-fluid">
				
				<!-- Begin page heading -->
				<h1 class="page-heading">Pioneer <small>Computers Private Limited</small></h1>
				<!-- End page heading -->
				
					<!-- BEGIN EXAMPLE ALERT -->
					<div class="alert alert-warning alert-bold-border fade in alert-dismissable">
					  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					  <p><strong>Welcome!</strong></p>
					  <p class="text-muted">Welcome to the PCPL's admin panel..!! You can view and delete vital information of your website here.<br/> 

For security reasons, please don't share your user id and password with anyone. <i class="fa fa-smile-o"></i></p>
					</div>
					<!-- END EXAMPLE ALERT -->
				
					
					<!-- BEGIN SiTE INFORMATIONS -->
					<div class="row">
						<div class="col-sm-6">
							<div class="the-box no-border bg-success tiles-information">
								<i class="fa fa-users icon-bg"></i>
								<div class="tiles-inner text-center">
									<p>Total Enquries</p>
									<h1 class="bolded"><?=$TotalEnquiryCount->cnt;?></h1> 
									<div class="progress no-rounded progress-xs">
									  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
									  </div><!-- /.progress-bar .progress-bar-success -->
									</div><!-- /.progress .no-rounded -->
									
								</div><!-- /.tiles-inner -->
							</div><!-- /.the-box no-border -->
						</div><!-- /.col-sm-3 -->
						<div class="col-sm-6">
							<div class="the-box no-border bg-primary tiles-information">
								<i class="fa fa-shopping-cart icon-bg"></i>
								<div class="tiles-inner text-center">
									<p>Total Offices</p>
									<h1 class="bolded"><?=$TotalOfficessCount->cnt;?></h1> 
									<div class="progress no-rounded progress-xs">
									  <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
									  </div><!-- /.progress-bar .progress-bar-primary -->
									</div><!-- /.progress .no-rounded -->
								</div><!-- /.tiles-inner -->
							</div><!-- /.the-box no-border -->
						</div><!-- /.col-sm-3 -->
					</div><!-- /.row -->
					<!-- END SITE INFORMATIONS -->
				
						<div class="col-lg-12">
						
							<!-- BEGIN WEATHER WIDGET 3 -->
							<!-- /.the-box bg-info no-border -->
							<!-- END WEATHER WIDGET 2 -->
							
							<!-- BEGIN SOCIAL TILES -->
							<div class="row">
							   <a target="_blank" href="https://www.facebook.com/jupiter.infra">
                                    <div class="col-xs-3">
                                        <div class="tiles facebook-tile text-center">
                                            <i class="fa fa-facebook icon-lg-size"></i>
                                            <h4><a target="_blank" href="http://pioneercpl.com/">View</a></h4>
                                        </div><!-- /.tiles .facebook-tile -->
                                    </div><!-- /.col-xs-6 -->
                                </a>
								<a target="_blank" href="https://twitter.com/JupiterInfra">
                                    <div class="col-xs-3">
                                        <div class="tiles twitter-tile text-center">
                                            <i class="fa fa-twitter icon-lg-size"></i>
                                            <h4><a target="_blank" href="http://pioneercpl.com/">View</a></h4>
                                        </div><!-- /.tiles .twitter-tile -->
                                    </div>
                                </a><!-- /.col-xs-6 -->
								<a target="_blank" href="https://plus.google.com/104924462040283609153/">
                                    <div class="col-xs-3">
                                        <div class="tiles google-tile text-center">
                                            <i class="fa fa-google icon-lg-size"></i>
                                            <h4><a target="_blank" href="http://pioneercpl.com/">View</a></h4>
                                        </div><!-- /.tiles .dribbble-tile -->
                                    </div>
                                </a><!-- /.col-xs-6 -->
								<a target="_blank" href="http://www.jupiterinfra.com">
                                    <div class="col-xs-3">
                                        <div class="tiles linkedin-tile text-center">
                                            <i class="glyphicon glyphicon-globe icon-lg-size"></i>
                                            <h4><a href="http://pioneercpl.com/">Website</a></h4>
                                        </div><!-- /.tiles .dribbble-tile -->
                                    </div><!-- /.col-xs-6 -->
                                </a>
							</div><!-- /.row -->
							<!-- END SOCIAL TILES -->
							
							
							
						</div><!-- /.col-sm-4 -->
					</div><!-- /.row -->
				
				</div><!-- /.container-fluid -->
				
				
				
				
              
<?php $this->load->view('footer'); ?>