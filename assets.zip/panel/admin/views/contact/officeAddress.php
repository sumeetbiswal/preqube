<?php $this->load->view('header');
	$this->load->view('side'); ?>

<div class="wrapper">				
	<div class="page-content">			
		<div class="container-fluid">
        		<h1 class="page-heading">Contact &nbsp; Page &nbsp; Adderss </h1>
                &nbsp; <?php if(isset($successUpdt)){ echo $successUpdt; }  ?> 
    		<div class="the-box">
							<h3 class="small-title">Added Address List</h3>
                            <br>
                            
                          <div class="the-box">
                            <div class="table-responsive">
                            <table class="table table-striped table-hover" id="datatable-example">
                                <thead class="the-box dark full">
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Office Location</th>
                                        <th>Contact Person</th>
                                        <th>Address</th>
                                        <th>Phone</th>
                                        <th>Mobile No.</th>
                                        <th>E-mail</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                            <?php
									if(!empty($officeAddress))
									{
										foreach($officeAddress as $value)
										{
											static $cnt = 1;
							?>              <tr class="odd gradeX">
                                                <td><?=$cnt;?></td>
                                                <td><?=$value->address_lable;?></td>
                                                <td><?=$value->contact_person;?></td>
                                                <td><?=$value->address;?></td>
                                                <td><?=$value->phone;?></td>
                                                <td><?=$value->mobile;?></td>
                                                <td><?=$value->email;?></td>
                                                <td class="center"><a href="<?php echo WEB_ADMIN_URL; ?>contact/officess/edit/<?=$value->id; ?>" ><img src="<?php echo WEB_ADMIN_DIR; ?>/assets/img/icon_edit.png" height="14" width="14" alt="Edit" title="Edit" /></a>
                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                <a href="<?php echo WEB_ADMIN_URL; ?>contact/deleteAddress/<?=$value->id; ?>" onclick="return ask();"><img src="<?php echo WEB_ADMIN_DIR; ?>/assets/img/cross.png" height="14" width="14" alt="Delete" title="Delete" /></a></td>
                                            </tr>
                                 <?php
								 		$cnt++;
									    } 
									}
								?>
                                </tbody>
    
                            </table>
                            </div><!-- /.table-responsive -->
                        </div>
					</div>
                            
             
                            
              <div class="col" style="margin-left:-15px;">
				<div class="col-sm-6">	
                    <div class="the-box">
							<h4 class="small-title">ADD &nbsp; ADDRESS</h4>
                             &nbsp; <?php if(isset($success)){ echo $success; }  ?> 
								<form role="form" name="change_md" action="<?php echo WEB_ADMIN_URL ?>contact/officess" method="post" enctype="multipart/form-data">
								  
                                  <div class="form-group">
									<label>Office Location :</label>
									<input type="text" name="office_desig" class="form-control" placeholder="Office Location" required>
								  </div>
                                  
                                  <div class="form-group">
									<label>Contact Person :</label>
									<input type="text" name="contact_person" class="form-control" placeholder="Contact Person" required>
								  </div>
                                  
                                  <div class="form-group">
									<label>Address :</label>
									<textarea class="form-control" name="office_address" placeholder="Office Address" rows="8" ></textarea>
								  </div>
                                  
                                  <div class="form-group">
									<label>Phone Numbers :</label>
									<input type="text" name="phone_contact" class="form-control" placeholder="Phone Numbers" required>
								  </div>
                                  
                                  <div class="form-group">
									<label>Mobile Numbers :</label>
									<input type="text" name="mobile_contact" class="form-control" placeholder="Mobile Numbers" required>
								  </div>
                                  
                                  <div class="form-group">
									<label>E-mail :</label>
									<input type="text" name="office_email" class="form-control" placeholder="Office Mailing Address" required>
								  </div>
                                  <p style="color:#900;">NOTE : For multiple mailing emails please seperate them with comma(,). </p>
                                  
								  <button type="submit" name="submit1" class="btn btn-success"><i class="fa fa-sign-in"></i> Submit</button>
								</form>
							</div>
                      </div>
                 </div>
                 <?php
				 	$checkEdit = $this->uri->segment(3);
					$addressID = $this->uri->segment(4);
					
					if($checkEdit == 'edit')
					{
						$this->load->model('contact_model','contact');
						$data = $this->contact->getAddressDetails($addressID);
						
					?>
						<div class="col" style="margin-left:-15px;">
							<div class="col-sm-6">	
								<div class="the-box">
										<h4 class="small-title">EDIT &nbsp; ADDRESS</h4>&nbsp; 
											<form role="form" name="change_md" action="<?php echo WEB_ADMIN_URL ?>contact/updateOfficeAddress/<?=$data->id;?>" method="post" enctype="multipart/form-data">
											  
											  <div class="form-group">
												<label>Office Location :</label>
												<input type="text" name="office_desig" value="<?=$data->address_lable;?>" class="form-control" placeholder="Office Location" required>
											  </div>
                                              
                                              <div class="form-group">
												<label>Contact Person :</label>
												<input type="text" name="contact_person" value="<?=$data->contact_person;?>" class="form-control" placeholder="Contact Person" required>
											  </div>
											  
											  <div class="form-group">
												<label>Address :</label>
												<textarea class="form-control" name="office_address" placeholder="Office Address" rows="8" required><?=stripslashes($data->address);?></textarea>
											  </div>
											  
											  <div class="form-group">
												<label>Phone Numbers :</label>
												<input type="text" name="phone_contact" value="<?=$data->phone;?>" class="form-control" placeholder="Phone Numbers" required>
											  </div>
                                              
                                              <div class="form-group">
												<label>Mobile Numbers :</label>
												<input type="text" name="mobile_contact" value="<?=$data->mobile;?>" class="form-control" placeholder="Mobile Numbers" required>
											  </div>
											  
											  <div class="form-group">
												<label>E-mail :</label>
												<input type="text" name="office_email" value="<?=$data->email;?>" class="form-control" placeholder="Office Mailing Address" required>
											  </div>
											  <p style="color:#900;">NOTE : For multiple mailing emails please seperate them with comma(,). </p>
                                              
											  <button type="submit" class="btn btn-success"><i class="fa fa-sign-in"></i> Update</button> &nbsp;<a href="<?php echo WEB_ADMIN_URL ?>contact/officess"> <button type="button" class="btn btn-danger" ><i class="fa fa-sign-out"></i> Cancle</button></a>
											</form>
										</div>
								  </div>
							 </div>
				<?php	}  ?>
				 
             </div>
        </div>
   </div>

<?php $this->load->view('footer'); ?>
<script  type="text/javascript">
  
  			$('#offices').addClass('active');
			$('#offices').addClass('selected');
  			$('#contact').addClass('visible');
			
			function ask()
			   {
					var ask = confirm('Are You sure?');   
					
					if(ask)
						return true;
					else
						return false;
			   }
  </script>