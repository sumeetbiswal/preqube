<?php $this->load->view('header');
	$this->load->view('side'); ?>
	
  	
<div class="wrapper">				
	<div class="page-content">			
		<div class="container-fluid">
    		<div class="row">
				
                    <div class="the-box">
							<h3 class="small-title">Contact Enquiry List</h3>
           
                          <div class="the-box">
                            <div class="table-responsive">
                            <table class="table table-striped table-hover" id="datatable-example">
                                <thead class="the-box dark full">
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Subject</th>
                                        <th>Message</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                            <?php
									if(!empty($contact))
									{
										foreach($contact as $value)
										{
											static $cnt = 1;
							?>              <tr class="odd gradeX">
                                                <td><?=$cnt;?></td>
                                                <td><?=$value->name;?></td>
                                               	<td><?=$value->email;?></td>
                                                <td><?=$value->subject;?></td>
                                                <td><?=$value->message;?></td>
                                                
                                                <td class="center">
                                                <a href="<?php echo WEB_ADMIN_URL; ?>contact/deleteContact/<?=$value->sl_no; ?>" onclick="return ask();"><img src="<?php echo WEB_ADMIN_DIR; ?>/assets/img/cross.png" height="14" width="14" alt="Delete" title="Delete" /></a>
                                               &nbsp;&nbsp;
                                              
                                               
                                               </td>
                                            </tr>
                                 <?php
								 		$cnt++;
									  } 
									  	}?>
                                </tbody>
    
                            </table>
                            </div><!-- /.table-responsive -->
                        </div>
							</div>
                       
                   </div>
               </div>
           </div>
      </div>
    
  
<?php $this->load->view('footer'); ?>


<script  type="text/javascript">
  
  			$('#enquery').addClass('active');
			$('#enquery').addClass('selected');
  			$('#contact').addClass('visible');
			
			 function ask()
			   {
					var ask = confirm('Are You sure?');   
					
					if(ask)
						return true;
					else
						return false;
			   }
  </script>