<div class="sidebar-left sidebar-nicescroller">
				<ul class="sidebar-menu">
					<li><a href="<?php echo WEB_ADMIN_URL; ?>manage/"><i class="fa fa-dashboard icon-sidebar"></i>Dashboard</a></li>
                   <!-- <li><a href="<?php //echo WEB_ADMIN_URL; ?>manage/backup"><i class="fa fa-dashboard icon-sidebar"></i>Backup</a></li>-->
                    <!--<li>
						<a href="#fakelink">
							<i class="fa fa-home icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Home Page
							<span class="badge badge-info span-sidebar" id="hom">3</span>
							</a>
						<ul class="submenu" id="hume">
                        	<li id="baner"><a href="<?php //echo WEB_ADMIN_URL; ?>home/banner">Banners</a></li>
							<li id="humMsg"><a href="<?php //echo WEB_ADMIN_URL; ?>home">Messages</a></li>
							<li id="testymonal"><a href="<?php //echo WEB_ADMIN_URL; ?>home/testimonial">Testimonials</a></li>																																																																																																														
						</ul>
					</li>
					<li>
						<a href="#fakelink">
							<i class="fa fa-desktop icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Project
							<span class="badge badge-info span-sidebar" id="proj">4</span>
							</a>
						<ul class="submenu" id="prjct">	
							<li id="adprjct"><a href="<?php //echo WEB_ADMIN_URL; ?>project/add">Add Project</a></li>
                            <li id="gallery"><a href="<?php //echo WEB_ADMIN_URL; ?>project/gallery">Project Images</a></li>
							<li id="vwprjct"><a href="<?php //echo WEB_ADMIN_URL; ?>project/projectList">Project List</a></li>
                            <li id="prjupdate"><a href="<?php //echo WEB_ADMIN_URL; ?>project/projectUpdate">Construction Update</a></li>
                            <li id="prjenqry"><a href="<?php //echo WEB_ADMIN_URL; ?>project/enquiry">Enquiry</a></li>
							<li><a href="javascript:void(0);">No Link</a></li>																																																																																																																
						</ul>
					</li>
                    <li>
						<a href="#fakelink">
							<i class="glyphicon glyphicon-hand-right icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Extra
							<span class="badge badge-info span-sidebar" id="extr">3</span>
							</a>
						<ul class="submenu" id="extra">	
							<li id="rqstclbck"><a href="<?php //echo WEB_ADMIN_URL; ?>extra/callbackRequest">Callback Request</a></li>
							<li id="foter"><a href="<?php //echo WEB_ADMIN_URL; ?>footer/footMessage">Footer</a></li>
                            <li id="newsy"><a href="<?php //echo WEB_ADMIN_URL; ?>extra/newsSubscribers">News Letter</a></li>																																																																																																													
						</ul>
					</li>
                    <li>
                    	<a href="#fakelink">
							<i class="glyphicon glyphicon-globe icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Services
							<span class="badge badge-info span-sidebar" id="serv">6</span>
							</a>
						<ul class="submenu" id="services">
                        	<li id="postSale"><a href="<?php //echo WEB_ADMIN_URL; ?>services/postSale">Post Sale Services</a></li>
                            <li id="legal"><a href="<?php //echo WEB_ADMIN_URL; ?>services/legalAssist">Legal Assistance</a></li>	
							<li id="loan"><a href="<?php //echo WEB_ADMIN_URL; ?>services/loanAssist">Loan Assistance</a></li>
                            <li id="investors"><a href="<?php //echo WEB_ADMIN_URL; ?>services/investGuide">Investors Guide</a></li>
                            <li id="faq"><a href="<?php //echo WEB_ADMIN_URL; ?>services/faq">FAQ</a></li>	
							<li id="nri"><a href="<?php //echo WEB_ADMIN_URL; ?>services/nriInvestors">NRI Investors Guide</a></li>
						</ul>
                    </li>
 		            <li>
						<a href="#fakelink">
							<i class="glyphicon glyphicon-user icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Partner
							<span class="badge badge-info span-sidebar" id="part">2</span>
							</a>
						<ul class="submenu" id="partner">	
							<li id="adpr"><a href="<?php //echo WEB_ADMIN_URL; ?>extra/partner">New Partner</a></li>
							<li id="prtl"><a href="<?php //echo WEB_ADMIN_URL; ?>extra/partnerList">Partner List</a></li>																																																																																																														
						</ul>
					</li>
                     <li>
						<a href="#fakelink">
							<i class="glyphicon glyphicon-film icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Gallery
							<span class="badge badge-info span-sidebar" id="gall">2</span>
							</a>
						<ul class="submenu" id="galery">	
							<li id="event"><a href="<?php //echo WEB_ADMIN_URL; ?>gallery/event">Events</a></li>
							<li id="media"><a href="<?php //echo WEB_ADMIN_URL; ?>gallery/media">Media</a></li>																																																																																																														
						</ul>
					</li>-->
                    <li>
						<a href="#fakelink">
							<i class="glyphicon glyphicon-earphone icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Contact Us
							<span class="badge badge-info span-sidebar" id="cont">2</span>
							</a>
						<ul class="submenu" id="contact">	
							<li id="enquery"><a href="<?php echo WEB_ADMIN_URL; ?>contact/enquery">Enquries</a></li>
							<li id="offices"><a href="<?php echo WEB_ADMIN_URL; ?>contact/officess">Office Address</a></li>
                            <!--<li id="map"><a href="<?php //echo WEB_ADMIN_URL; ?>contact/addMap">Map</a></li>	-->																																																																																																												
						</ul>
					</li>
                    
                    <!--<li>
						<a href="#fakelink">
							<i class="glyphicon glyphicon-eye-open icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							About Us
							<span class="badge badge-info span-sidebar" id="abus">5</span>
							</a>
						<ul class="submenu" id="about">	
							<li id="ovs"><a href="<?php //echo WEB_ADMIN_URL; ?>about/vision_mission_offer">Our Vision / Mission / Offered</a></li>
                            <li id="wwa"><a href="<?php //echo WEB_ADMIN_URL; ?>about/who_we_are">Who We Are</a></li>
                            <li id="wel"><a href="<?php //echo WEB_ADMIN_URL; ?>about/come_to_jupiter">Welcome to Jupiter</a></li>
                            <li id="promot"><a href="<?php //echo WEB_ADMIN_URL; ?>about/promoters">Management</a></li>
                            <li id="core"><a href="<?php //echo WEB_ADMIN_URL; ?>about/coreTeam">Team Jupiter</a></li>																																																																																																												
						</ul>
					</li>
                    
                    <li>
						<a href="#fakelink">
							<i class="glyphicon glyphicon-question-sign icon-sidebar"></i>
							<i class="fa fa-angle-right chevron-icon-sidebar"></i>
							Help
							<span class="badge badge-info span-sidebar" id="hel">6</span>
							</a>
						<ul class="submenu" id="help">	
							<li id="loginhelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/loginHelp">Login</a></li>
                            <li id="dashboardhelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/dashboardHelp">Dashboard</a></li>
                            <li id="projhelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/projectHelper">Projects</a></li>
							<li id="exthelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/extraHelper">Extra Contents</a></li>
                            <li id="homehelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/homePageHelper">Home Page Contents</a></li>		
                            <li id="partnerhelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/partnerHelper">Partners</a></li>
							<li id="galleryhelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/galleryHelper">Gallery</a></li>
                            <li id="contacthelp"><a href="<?php //echo WEB_ADMIN_URL; ?>help/contactHelper">Contacts</a></li>																																																																																																												
						</ul>
					</li>-->
				</ul>	
			</div>