<!-- BEGIN FOOTER -->
				<footer>
					&copy; 2014 <a href="http://pioneercpl.com//">Pioneer Computers Pvt. Ltd.</a>
				</footer>
				<!-- END FOOTER -->
				
				
			</div>
            <!--END CONTENT-->
            <!--LOADING SCRIPTS FOR PAGE-->

</div>
<script src="<?php echo WEB_ADMIN_DIR; ?>assets/js/jquery.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/retina/retina.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/nicescroll/jquery.nicescroll.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/backstretch/jquery.backstretch.min.js"></script>
 
		<!-- PLUGINS -->
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/skycons/skycons.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/prettify/prettify.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/owl-carousel/owl.carousel.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/chosen/chosen.jquery.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/icheck/icheck.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/datepicker/bootstrap-datepicker.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/timepicker/bootstrap-timepicker.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/mask/jquery.mask.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/validator/bootstrapValidator.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/datatable/js/bootstrap.datatable.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/summernote/summernote.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/markdown/markdown.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/markdown/to-markdown.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/markdown/bootstrap-markdown.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/slider/bootstrap-slider.js"></script>
	
		<!-- EASY PIE CHART JS -->
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/easypie-chart/easypiechart.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/easypie-chart/jquery.easypiechart.min.js"></script>
		
		<!-- KNOB JS -->
		<!--[if IE]>
		<script type="text/javascript" src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/jquery-knob/excanvas.js"></script>
		<![endif]-->
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/jquery-knob/jquery.knob.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/jquery-knob/knob.js"></script>

	

		<!-- MORRIS JS -->
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/morris-chart/raphael.min.js"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/morris-chart/morris.min.js"></script>
		
		<!-- C3 JS -->
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/c3-chart/d3.v3.min.js" charset="utf-8"></script>
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/c3-chart/c3.min.js"></script>
		
		<!-- MAIN APPS JS -->
		<script src="<?php echo WEB_ADMIN_DIR; ?>assets/js/apps.js"></script>
		
        <script src="<?php echo WEB_ADMIN_DIR; ?>assets/plugins/validator/example.js"></script>
	</body>
</html>
