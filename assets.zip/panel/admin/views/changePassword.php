<?php $this->load->view('header');
	$this->load->view('side'); ?>
	
  	
<div class="wrapper">				
	<div class="page-content">			
		<div class="container-fluid">
    		<div class="row">
				<div class="col-sm-6">	
                    <div class="the-box">
							<h4 class="small-title">RESET &nbsp; PASSWORD</h4>
								<form role="form" name="change_pass" action="<?php echo WEB_ADMIN_URL ?>manage/changePassword" method="post">
								  <div class="form-group">
									<label>New Password</label>
									<input type="password" class="form-control" name="password" placeholder="New Password" required>
								  </div>
								  <div class="form-group">
									<label>Conform Password</label>
									<input type="password" class="form-control" name="conf_pass" placeholder="Conform Password" required>
								  </div>
								  
								  <button type="submit" class="btn btn-success"><i class="fa fa-sign-in"></i> Save</button>
								</form>
							</div>
                        </div>
                   </div>
               </div>
           </div>
      </div>
    
    
<?php $this->load->view('footer'); ?>