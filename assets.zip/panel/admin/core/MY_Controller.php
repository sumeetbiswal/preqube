<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class My_controller extends CI_Controller {

	
	function __construct()
	{
		parent::__construct();	
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
		ob_start();
	}
	
	public function check_login()
	{
		if (!$this->session->userdata('admin_logged_in')) 
			  redirect('login', 'refresh');
	}
	
	public function echocsv($fields)
    {
		$separator = '';
		foreach ( $fields as $field )
		{
		  if ( preg_match( '/\\r|\\n|,|"/', $field ) )
		  {
			$field = '"' . str_replace( '"', '""', $field ) . '"';
		  }
		  echo $separator . $field;
		  $separator = ',';
		}
		echo "\r\n";
  }
  
  	function create_zip($files = array(), $dest = '', $overwrite = false) 
	{
		if (file_exists($dest) && !$overwrite) 
		{
			return false;
		}
		
		if (($files)) 
		{
			$zip = new ZipArchive();
			if ($zip->open($dest, $overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) {
				return false;
			}
			foreach ($files as $file) {
				$zip->addFile($file, $file);
			}
			$zip->close();
			return file_exists($dest);
		} 
		else 
		{
			return false;
		}
	
	}
	
	function addzip($source, $destination) 
	{
		$files_to_zip = glob($source . '/*');
		$this->create_zip($files_to_zip, $destination);
		echo "done";
	}
}

