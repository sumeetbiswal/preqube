<?php 

class Admin_model extends CI_Model {
	
	public function __construct()
    {
      parent::__construct();
	
    }
	
	public function verify_user($email, $password)
   {
   	
		$this->db->select('id, name, email, is_super')
			->from('admin')
			->where('email', $email)
            ->where('password', md5($password))
			->where('status', '1')
			->limit(1);
			
		
		$query = $this->db->get();
		
      	if ( $query->num_rows > 0 )
	    {
        	 return $query->row();
        }
      	return false;
   }
   
   public function fetchMenuList($id)
   {
		$this->db->select('*')	 
				->from('privillege')
				->where('adminid',$id);
				
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->row();
		else
			return '';
   }
   
   public function getAdminDetails()
   {
		$id = $this->session->userdata('user_id');	  
		
		$this->db->select('*')	 
				->from('admin')
				->where('status','1')
				->where('id',$id);
				
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return '';
   }
   
   public function updateAdminDetails($data)
   {
		$this->db->update('admin',$data);   
		
		return true;
   }
   
   public function changePassword($data)
   {
	   $idd = $this->session->userdata('user_id');
	   
	   	$this->db->update('admin',$data,array("id"=>$idd)); 
		
		return true;
   }
   
   public function getLogo()
   {
		$this->db->select('*')
				->from('admin_logo')
				->where('id','1');
			
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
				return $query->row();
		else
				return ''; 	 
   }
   
   public function changeAvatar($data)
   {
		$this->db->update('admin_logo',$data,array('id'=>'1'))  ;
		
		return true;
	}
	
   public function getLocationId($loc)
   {
		$this->db->select('loc_id')
				->from('location')
				->where('loc_name',$loc);
			
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
				return $query->row();
		else
				return '';
   }
   
   public function checkEmailAvailablity($email)
   {
		$this->db->select('*')
				 ->from('member')
				 ->where('username',$email);
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
				return false;
		else
				return true;
   }
   
   public function loadArtistByType($type)
   {
		$this->db->select('*')
			 ->from($type)
			 ->where('status','1');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
				return $query->result();
		else
				return '';
   }
   
   public function getProfilePic($type)
   {
		  $this->db->select('id,avatar')
			 ->from($type)
			 ->where('status','1');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
				return $query->result();
		else
				return '';
	}
	
	public function getPortfolioPic($type)
   {
		  $this->db->select($type.'_id as id,image')
			 ->from($type.'_portfolio');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
				return $query->result();
		else
				return '';
	}
	
	public function addCasting($data)
	{
		
		$this->db->insert('casting',$data);
		
		return true;
	}
	
	public function updateCasting($data,$id)
	{
		$this->db->update('casting',$data,array('id'=>$id));
		
		return true;
	}
	
	public function getCastingList()
	{
		$query = $this->db->select('*')->from('casting')->order_by('id','DESC')->get();
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return '';
	}
	
	public function getCastingAppliedList()
	{
		$query = "select ca.*,c.title from casting c,casting_apply ca where ca.chanceid=c.chanceid";
		
		$query = $this->db->query($query);
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return '';
	}
	
	public function getArtistName($type,$id)
	{
		$query = $this->db->select('*')->from($type)->where('id',$id)->get();
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return '';
	}
	public function getCastingById($id)
	{
		$query = $this->db->select('*')->from('casting')->where('id',$id)->get();
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return '';	
	}
	
	public function deleteCasting($id)
	{
		$this->db->delete('casting',array('id'=>$id));	
		
		return true;
	}
	
	public function deleteCastingApply($id)
	{
		$this->db->delete('casting_apply',array('id'=>$id));	
		
		return true;
	}
	
	public function setPhoto($path,$file,$image_link,$imagetitle,$title_link)
	{
		$data = array(
		
					'path'	=>	$path,
					'image'	=>	$file,
					'link'	=>	$image_link,
					'title'	=>	$imagetitle,
					'titlelink'=>$title_link
				);	
				
		$query = $this->db->insert('home_slide',$data);
		
		if($this->db->insert_id())
				return $this->db->insert_id();
		else
				return false;
	}
	
	public function setClientPhoto($path,$file)
	{
		$data = array(
		
					'path'	=>	$path,
					'image'	=>	$file
				);	
				
		$query = $this->db->insert('client_logo',$data);
		
		if($this->db->insert_id())
				return $this->db->insert_id();
		else
				return false;
	}
	
	public function getSlidePhoto()
	{
		$query = $this->db->get('home_slide');	
		
		return $query->result();
	}
	
	public function getClientLogoById($id)
	{
		$query = $this->db->select('*')->from('client_logo')->where('id',$id)->get();	
		
		return $query->result();	
	}
	
	public function getClientLogo()
	{
		$query = $this->db->get('client_logo');	
		
		return $query->result();
	}
	
	public function removeHomeImage($id)
	{
		$this->db->delete('home_slide',array('id'=>$id));	
		
		return true;
	}
	
	public function removeClientImage($id)
	{
		$this->db->delete('client_logo',array('id'=>$id));	
		
		return true;
	}
	
	public function countTotalEnquiries()
	{
		$this->db->select('count(*) as cnt');
		$this->db->from('contact_enquiry');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->row();
		else
			return '';
	}
	
	public function countTotalOffices()
	{
		$this->db->select('count(*) as cnt');
		$this->db->from('office_address');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->row();
		else
			return '';
	}
}

