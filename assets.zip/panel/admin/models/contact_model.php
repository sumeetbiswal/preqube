<?php 

class Contact_model extends CI_Model {
	
	public function __construct()
    {
      parent::__construct();
	
    }
	
	public function getAddedOffices()
	{
		$this->db->select('*');	
		$this->db->from('office_address');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return false;	
	}
	public function addNewAddress($data)
	{
		$this->db->insert('office_address',$data);	
		
		return true;
	}
	
	public function updateAddress($data,$id)
	{
		$this->db->update('office_address',$data,array('id'=>$id));	
		
		return true;
	}
	
	public function deleteAddres($id)
	{
		$this->db->delete('office_address',array('id'=>$id));
		
		return true;
	}
	
	public function getAddressDetails($id)
	{
		$this->db->select('*');	
		$this->db->from('office_address');
		$this->db->where('id',$id);
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->row();
		else
			return false;
	}
	
	public function getAllContact()
	{
		$this->db->select('*');	
		$this->db->from('contact_enquiry');
		$this->db->order_by('sl_no','DESC');
		
		$query = $this->db->get();
		
		if($query->num_rows() > 0)
			return $query->result();
		else
			return false;
	}
	
	public function deleteContact($id)
	{
		$this->db->delete('contact_enquiry',array('sl_no'=>$id));	
		
		return true;
	}
	
}

