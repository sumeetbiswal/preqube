<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact extends My_Controller {
	
	public function __construct()
	{
		parent::__construct();
		parent::check_login();
		$this->load->model('contact_model','contact');
	}
	
	public function officess()
	{
		if(isset($_POST['submit1']))
		{
			extract($_POST);	
		
			$data = array(
					
					'address_lable'			=>	$office_desig,
					'contact_person'  		=>	$contact_person,
					'address'				=>	$office_address,
					'phone'					=>	$phone_contact,
					'mobile'  				=>	$mobile_contact,
					'email'					=>	$office_email
				);
				
			$status = $this->contact->addNewAddress($data);
			
			if($status)
				$data['success'] = '<div class="alert alert-success fade in alert-dismissable">
								  <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								  Added Successfully...
								</div>';
			else
				$data['success'] = '<div class="alert alert-danger fade in alert-dismissable">
								  <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>Failed Try Again...</div>';
		}
		
		$data['title'] = 'Contact | Officess';	
		
		$data['officeAddress'] = $this->contact->getAddedOffices();
		
		$this->load->view('contact/officeAddress',$data);
	}
	
		
	public function deleteAddress($id)
	{	
		$this->contact->deleteAddres($id);	
		
		redirect('contact/officess','refresh');	
	}
	
	public function updateOfficeAddress($id)
	{
		extract($_POST);	
		
		$data = array(
					
					'address_lable'			=>	$office_desig,
					'contact_person'  		=>	$contact_person,
					'address'				=>	$office_address,
					'phone'					=>	$phone_contact,
					'mobile'  				=>	$mobile_contact,
					'email'					=>	$office_email
				);
				
			$status = $this->contact->updateAddress($data,$id);
			
			
		
		$data['title'] = 'Contact | Officess';	
		
		$data['officeAddress'] = $this->contact->getAddedOffices();
		
		redirect('contact/officess','refresh');
	}
	
	public function enquery()
	{
		$data['title'] = 'Enqury | List';
		
		$data['contact'] = $this->contact->getAllContact();
		
		$this->load->view('contact/enquiry',$data);
	}
	
	public function deleteContact($id)
	{
		$this->contact->deleteContact($id);	
		
		redirect('contact/enquery','refresh');
	}
	
}

