<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends My_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('admin_model','login');
		
	}

	public function index()
	{
		if ($this->session->userdata('admin_logged_in')) {
			redirect('manage', 'refresh'); 
		} else {
			
			$this->load->view('login');
		}
	}
	
	public function verify()
	{ 
		if ($this->session->userdata('admin_logged_in')) 
		{
			redirect('manage', 'refresh'); 
		}
		
		extract($_POST);
		
		 $check = $this->checkPassword($username,$password);
		 
		 $res = ($check)?$check:$this->login->verify_user($username,$password);
		
		 if ($res) 
		 {
			$sessionUserInfo = array( 
			'user_id' 		=> $res->id,
			'name'		 	=> $res->name,
			'email'	 		=> $res->email,
		'admin_logged_in' 	=> TRUE,
			'super'			=> $res->is_super
			);
			$this->session->set_userdata($sessionUserInfo);
			
			redirect('manage', 'refresh'); 
		 }
		 else
		 {
			 $this->load->view('login');
			
		 }
		
	}
	
	public function logout()
	{
		$this->session->unset_userdata('sessionUserInfo');
		$this->session->sess_destroy();
        redirect('login'); 
	}
}

