<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage extends My_Controller {
	
	public function __construct()
	{
		parent::__construct();
		parent::check_login();
		$this->load->model('admin_model','admin');
	}

	public function index()
	{
		if (!$this->session->userdata('admin_logged_in')) 
			  redirect('login', 'refresh');
			  
		$data['title'] = 'Dashboard | Dashboard';
			
		$data['TotalEnquiryCount'] = $this->admin->countTotalEnquiries();
		$data['TotalOfficessCount'] = $this->admin->countTotalOffices();
			
		$this->load->view('dashboard',$data);
	}
	
	public function profile()
	{
		$data['details'] = $this->admin->getAdminDetails();
		$this->load->view('profile',$data);	
	}
	
	public function editProfile($id)
	{
		extract($_POST);
		
		$data = array(
		
					'name'  => $name,
					'email' => $email
		);
		
		$this->admin->updateAdminDetails($data);
		
		redirect('manage/profile');
	}
	
	public function password()
 	{
  		$data['title'] = 'Change | Password';
  
  		$this->load->view('changePassword',$data);
 	}
	
	public function changePassword()
	{
		extract($_POST);
		
		$data = array(
					'password' => md5($password)
				);
				
		$this->admin->changePassword($data);
		
		redirect('manage');
	}
		
}

